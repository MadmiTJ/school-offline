// Агар холӣ бошад — инисиализатсия
if (!localStorage.getItem("students")) {
  localStorage.setItem("students", JSON.stringify([]));
}
if (!localStorage.getItem("subjects")) {
  localStorage.setItem("subjects", JSON.stringify([]));
}
if (!localStorage.getItem("grades")) {
  localStorage.setItem("grades", JSON.stringify([]));
}

// helpers
function getData(key) {
  return JSON.parse(localStorage.getItem(key));
}
function setData(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}