const lang = localStorage.getItem("lang") || "tj";

const words = {
  tj: {
    title: "Директор",
    reports_s: "Ҳисоботи умумӣ",
    reports: "Ҳисобот",
    schedule_s: "Дарсҳо",
    schedule: "Ҷадвали дарсҳо",
    grades_s: "Натиҷаҳо",
    grades: "Баҳои хонандагон",
    attendance_s: "Назорат",
    attendance: "Ҳозир / Ғоиб",
    students_s: "Рӯйхат",
    students: "Хонандагон",
    teachers_s: "Кормандон",
    teachers: "Муаллимон"
  },
  ru: {
    title: "Директор",
    reports_s: "Общий отчет",
    reports: "Отчёты",
    schedule_s: "Уроки",
    schedule: "Расписание",
    grades_s: "Результаты",
    grades: "Оценки учеников",
    attendance_s: "Контроль",
    attendance: "Посещаемость",
    students_s: "Список",
    students: "Ученики",
    teachers_s: "Персонал",
    teachers: "Учителя"
  },
  en: {
    title: "Director",
    reports_s: "General report",
    reports: "Reports",
    schedule_s: "Lessons",
    schedule: "Schedule",
    grades_s: "Results",
    grades: "Student Grades",
    attendance_s: "Control",
    attendance: "Attendance",
    students_s: "List",
    students: "Students",
    teachers_s: "Staff",
    teachers: "Teachers"
  }
};

const t = words[lang];

Object.keys(t).forEach(id => {
  const el = document.getElementById(id);
  if (el) el.innerText = t[id];
});