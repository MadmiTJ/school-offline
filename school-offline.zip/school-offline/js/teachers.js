const lang = localStorage.getItem("lang") || "tj";

const words = {
  tj: {
    title: "Муаллим",

    report_s: "Маълумот",
    report: "Хисобот",

    schedule_s: "Дарсҳо",
    schedule: "Ҷадвали дарсҳо",

    grades_s: "Арзёбӣ",
    grades: "Мондaни баҳои хонандагон",

    attendance_s: "Назорат",
    attendance: "Ҳозир / ғоиб",

    parents_s: "Алоқа",
    parents: "Волидайн",

    library_s: "Манбаъҳо",
    library: "Китобхона"
  },

  ru: {
    title: "Учитель",

    report_s: "Информация",
    report: "Отчёты",

    schedule_s: "Уроки",
    schedule: "Расписание",

    grades_s: "Оценивание",
    grades: "Выставление оценок",

    attendance_s: "Контроль",
    attendance: "Присутствие / отсутствие",

    parents_s: "Связь",
    parents: "Родители",

    library_s: "Ресурсы",
    library: "Библиотека"
  },

  en: {
    title: "Teacher",

    report_s: "Information",
    report: "Reports",

    schedule_s: "Lessons",
    schedule: "Schedule",

    grades_s: "Assessment",
    grades: "Student grading",

    attendance_s: "Control",
    attendance: "Attendance",

    parents_s: "Contact",
    parents: "Parents",

    library_s: "Resources",
    library: "Library"
  }
};

const t = words[lang];

Object.keys(t).forEach(id => {
  const el = document.getElementById(id);
  if (el) el.innerText = t[id];
});