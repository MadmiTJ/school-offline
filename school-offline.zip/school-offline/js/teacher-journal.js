const lang = localStorage.getItem("lang") || "tg";

/* === Маълумоти пешбинишуда (аз директор) === */
const teacherData = {
    classes:["1А","1Б","2А","2Б"],
    subjects:["Математика","Забони тоҷикӣ"],
    students:{
        "1А":["Алиев А.","Каримова М."],
        "1Б":["Саидов И.","Назарова Д."],
        "2А":["Ҳусейнов Р."],
        "2Б":["Мирзоева Ш."]
    }
};

/* === Интихобҳо === */
let selected = {
    class:null,
    year:null,
    subject:null,
    quarter:null,
    date:null
};

function openModal(type){
    const modal=document.getElementById("modal");
    const content=document.getElementById("modalContent");
    content.innerHTML="";
    let items=[];

    if(type==="class") items=teacherData.classes;
    if(type==="subject") items=teacherData.subjects;
    if(type==="year") items=["2023-2024","2024-2025"];
    if(type==="quarter") items=["1","2","3","4"];

    items.forEach(i=>{
        const b=document.createElement("button");
        b.innerText=i;
        b.onclick=()=>{
            selected[type]=i;
            document.getElementById(type+"Text").innerText=i;
            modal.style.display="none";
        };
        content.appendChild(b);
    });
    modal.style.display="flex";
}

document.getElementById("modal").onclick=e=>{
    if(e.target.id==="modal") e.target.style.display="none";
};

function loadJournal(){
    selected.date=document.getElementById("dateSelect").value;
    if(!selected.class||!selected.year||!selected.subject||!selected.quarter||!selected.date){
        alert("Ҳама интихобҳоро пур кунед");
        return;
    }

    const key=`journal_${selected.class}_${selected.subject}_${selected.year}_${selected.quarter}_${selected.date}`;
    const tbody = document.getElementById("journalBody");
    tbody.innerHTML="";
    document.getElementById("journalCard").style.display="block";

    const students=teacherData.students[selected.class]||[];
    const saved=JSON.parse(localStorage.getItem(key))||{};

    students.forEach((name,i)=>{
        const tr=document.createElement("tr");

        tr.innerHTML=`
            <td>${i+1}</td>
            <td>${name}</td>
            <td>
                <input type="text" value="${saved.topic||""}" ${saved.topic?"disabled":""}>
            </td>
            <td>
                <input class="grade" value="${saved[name]||""}" ${saved[name]?"disabled":""}>
            </td>
            <td>
                <button class="save-btn ${saved[name]?"saved":""}">✅</button>
            </td>
        `;

        const btn=tr.querySelector(".save-btn");
        btn.onclick=()=>{
            const topic=tr.children[2].querySelector("input").value;
            const grade=tr.children[3].querySelector("input").value;

            if(!topic || !grade) return;

            saved.topic=topic;
            saved[name]=grade;
            localStorage.setItem(key,JSON.stringify(saved));

            tr.children[2].querySelector("input").disabled=true;
            tr.children[3].querySelector("input").disabled=true;
            btn.classList.add("saved");
        };

        tbody.appendChild(tr);
    });
}