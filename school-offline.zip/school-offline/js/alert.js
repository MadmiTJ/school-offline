// ===== ALERT.JS =====

// Эҷоди контейнер агар вуҷуд надошта бошад
if (!document.getElementById("customAlert")) {
    const alertHTML = `
        <div id="customAlert" class="alert-overlay">
            <div class="alert-box">
                <h3 id="alertTitle">Огоҳӣ</h3>
                <p id="alertMessage">Паём</p>
                <button onclick="closeAlert()">Фаҳмо</button>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML("beforeend", alertHTML);
}

// Функсия барои нишон додани alert
function showAlert(message, title = "Огоҳӣ") {
    document.getElementById("alertTitle").innerText = title;
    document.getElementById("alertMessage").innerText = message;
    document.getElementById("customAlert").classList.add("show");
}

// Функсия барои пӯшидани alert
function closeAlert() {
    document.getElementById("customAlert").classList.remove("show");
}
showAlert("Лутфан сана интихоб кунед");