const translations = {
  tg: {
    title: "Системаи идоракунии мактаб",
    subtitle: "Барои ворид шудан, нақшро интихоб кунед",
    director: "👨‍💼 Директор",
    teacher: "👩‍🏫 Муаллим",
    student: "🎓 Хонанда",
    parent: "👨‍👩‍👧 Волидайн",
    login_label: "Логин",
    password_label: "Парол",
    login_btn: "Ворид шудан",
    lang_name: "Тоҷикӣ"
  },
  ru: {
    title: "Система управления школой",
    subtitle: "Выберите роль для входа",
    director: "👨‍💼 Директор",
    teacher: "👩‍🏫 Учитель",
    student: "🎓 Ученик",
    parent: "👨‍👩‍👧 Родители",
    login_label: "Логин",
    password_label: "Пароль",
    login_btn: "Войти",
    lang_name: "Русский"
  },
  en: {
    title: "School Management System",
    subtitle: "Select a role to login",
    director: "👨‍💼 Director",
    teacher: "👩‍🏫 Teacher",
    student: "🎓 Student",
    parent: "👨‍👩‍👧 Parents",
    login_label: "Login",
    password_label: "Password",
    login_btn: "Login",
    lang_name: "English"
  }
};

let currentLang = localStorage.getItem("lang") || "tg";

function applyLanguage() {
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.dataset.i18n;
    if (translations[currentLang][key]) {
      el.textContent = translations[currentLang][key];
    }
  });

  document.getElementById("langBtn").textContent =
    "🌐 " + translations[currentLang].lang_name;
}

document.addEventListener("DOMContentLoaded", () => {
  applyLanguage();

  const modal = document.getElementById("langModal");

  document.getElementById("langBtn").onclick = () => {
    modal.classList.add("active");
  };

  document.getElementById("closeLang").onclick = () => {
    modal.classList.remove("active");
  };

  document.querySelectorAll(".lang-option").forEach(btn => {
    btn.onclick = () => {
      currentLang = btn.dataset.lang;
      localStorage.setItem("lang", currentLang);
      applyLanguage();
      modal.classList.remove("active");
    };
  });
});