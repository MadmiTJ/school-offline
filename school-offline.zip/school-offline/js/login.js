document.addEventListener("DOMContentLoaded", () => {

  const loginInput = document.getElementById("login");
  const passwordInput = document.getElementById("password");
  const loginBtn = document.getElementById("loginBtn");

  let selectedRole = "director";

  // интихоби нақш
  document.querySelectorAll(".role").forEach(role => {
    role.addEventListener("click", () => {
      document.querySelectorAll(".role").forEach(r => r.classList.remove("active"));
      role.classList.add("active");
      selectedRole = role.dataset.role;
    });
  });

  // ворид шудан
  loginBtn.addEventListener("click", () => {
    const login = loginInput.value.trim();
    const password = passwordInput.value.trim();

    if (!login || !password) {
      alert("Логин ва паролро ворид кунед");
      return;
    }

    if (login === "admin" && password === "1234") {

      if (selectedRole === "director") {
        window.location.href = "director.html";
      } else if (selectedRole === "teacher") {
        window.location.href = "teacher.html";
      } else if (selectedRole === "student") {
        window.location.href = "student.html";
      } else if (selectedRole === "parent") {
        window.location.href = "parent.html";
      }

    } else {
      alert("Логин ё парол нодуруст аст");
    }
  });

});