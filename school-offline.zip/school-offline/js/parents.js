const lang = localStorage.getItem("lang") || "tj";

const words = {
  tj: {
    title: "Волидайн",
    children: "Фарзандон",
    grades: "Баҳоҳо",
    messages: "Паёмҳо"
  },

  ru: {
    title: "Родители",
    children: "Дети",
    grades: "Оценки",
    messages: "Сообщения"
  },

  en: {
    title: "Parents",
    children: "Children",
    grades: "Grades",
    messages: "Messages"
  }
};

const t = words[lang];

Object.keys(t).forEach(id => {
  const el = document.getElementById(id);
  if (el) el.innerText = t[id];
});