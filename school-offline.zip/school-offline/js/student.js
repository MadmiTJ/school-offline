const lang = localStorage.getItem("lang") || "tj";

const words = {
  tj: {
    title: "Хонанда",

    schedule_s: "Дарсҳо",
    schedule: "Чадвали дарсҳо",

    grades_s: "Натиҷаҳо",
    grades: "Дидани баҳоҳо",

    library_s: "Манбаъҳо",
    library: "Китобхона"
  },

  ru: {
    title: "Ученик",

    schedule_s: "Уроки",
    schedule: "Расписание",

    grades_s: "Результаты",
    grades: "Просмотр оценок",

    library_s: "Ресурсы",
    library: "Библиотека"
  },

  en: {
    title: "Student",

    schedule_s: "Lessons",
    schedule: "Schedule",

    grades_s: "Results",
    grades: "View grades",

    library_s: "Resources",
    library: "Library"
  }
};

const t = words[lang];

Object.keys(t).forEach(id => {
  const el = document.getElementById(id);
  if (el) el.innerText = t[id];
});